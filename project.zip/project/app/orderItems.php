<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class orderItems extends Model
{
    //
}
